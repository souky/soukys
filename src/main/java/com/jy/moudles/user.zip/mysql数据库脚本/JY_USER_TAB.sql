
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `JY_USER`
-- ----------------------------
DROP TABLE IF EXISTS `JY_USER`;
CREATE TABLE `JY_USER` (
 		`id` varchar(32) NOT NULL,
		`user_name` varchar(64) NOT NULL COMMENT '用户姓名',
		`user_tel` varchar(64) NOT NULL COMMENT '用户电话',
		`user_sex` tinyint(1) NOT NULL COMMENT '用户性别',
		`login_name` varchar(64) NOT NULL COMMENT '登陆名',
		`passwrod` varchar(64) NOT NULL COMMENT '密码',
		`user_img` varchar(64) NOT NULL COMMENT '用户头像',
		`org_code` varchar(64) NOT NULL COMMENT '机构代码',
		`open_id` varchar(64) NOT NULL COMMENT 'wx openId',
		`create_user`  varchar(64) NULL COMMENT '创建用户' ,
		`create_date`  datetime NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间' ,
		`update_user`  varchar(64) NULL COMMENT '更新用户' ,
		`update_date`  datetime NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间' ,
  		PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='$var[5]';
