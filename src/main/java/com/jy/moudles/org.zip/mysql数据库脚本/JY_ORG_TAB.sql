
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `JY_ORG`
-- ----------------------------
DROP TABLE IF EXISTS `JY_ORG`;
CREATE TABLE `JY_ORG` (
 		`id` varchar(32) NOT NULL,
		`p_id` varchar(64) NOT NULL COMMENT '上级机构id',
		`org_name` varchar(64) NOT NULL COMMENT '机构名称',
		`create_user`  varchar(64) NULL COMMENT '创建用户' ,
		`create_date`  datetime NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间' ,
		`update_user`  varchar(64) NULL COMMENT '更新用户' ,
		`update_date`  datetime NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间' ,
  		PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='$var[5]';
